HodgeProof Sponsor Pack — Supplementals
======================================

Timestamp (UTC): 2025-10-31 19:16:06Z

* Sponsor_Bundle_20251030_194849Z.zip — Main sponsor bundle
* Sponsor_Bundle_20251030_194849Z.zip.sha256.txt — SHA256 checksum

Supplemental Files:
  - Stage_Omega_FinalVerification.tex
  - Stage_Omega_FinalVerification.log
  - HodgeProof_Master.pdf
  - HodgeProof_Master_2.pdf
  - HodgeProof_Master_3.pdf
  - 2025-10-29-document-1.pdf
  - HodgeProof_Master_4.pdf
  - HodgeProof_Master_5.pdf
  - HodgeProof_Master_6.pdf
  - HodgeProof_Master_7.pdf
  - HodgeProof_Master_8.pdf
  - HodgeClean_Certification_Summary_PLACEHOLDER.pdf
  - Stage_Omega_FinalVerification_PLACEHOLDER.pdf
  - _reportlab_ok.pdf
  - HodgeProof_Master.pdf.pdf
  - Verification_Report_General.pdf
  - Verification_Report_General_2.pdf
  - HodgeClean_Certification_Summary_PLACEHOLDER_2.pdf
  - Stage_Omega_FinalVerification_PLACEHOLDER_2.pdf
  - Verification_Report_General_3.pdf
  - _reportlab_ok_2.pdf

Verify hash with:
  shasum -a 256 {inner.name}
