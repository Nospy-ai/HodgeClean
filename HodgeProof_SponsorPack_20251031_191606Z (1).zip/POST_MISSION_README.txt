HodgeProof Sponsor Pack — Supplementals
======================================

Timestamp (UTC): 2025-10-31 19:16:06Z

* Sponsor_Bundle_20251030_194849Z.zip — Main sponsor bundle
* Sponsor_Bundle_20251030_194849Z.zip.sha256.txt — SHA256 checksum

Supplemental Files:

Verify hash with:
  shasum -a 256 {inner.name}
