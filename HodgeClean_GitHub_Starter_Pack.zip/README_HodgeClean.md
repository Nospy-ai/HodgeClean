# HodgeClean
Author: David Manning — Independent Researcher (Galesburg, IL)

This repository contains the HodgeClean computational framework exploring closure metrics and algebraic invariants related to the Hodge Conjecture.

## Contents
- 2025-10-19-file-1_CLEAN.ipynb — Core SageMath notebook
- 2025-10-19-file-1_CLEAN.html — HTML view
- LICENSE.txt — Usage license
- CITATION.cff — Citation metadata

## License
This work is distributed under Creative Commons Attribution 4.0 International (CC BY 4.0). You may share and adapt the material, but must give appropriate credit to the author.
